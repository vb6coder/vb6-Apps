vbNES v0.1.3 by Mike Chambers
Released Feb. 5, 2016
=============================

About
=====

vbNES is a Nintendo Entertainment System written from scratch in VB6.
Why? Because I wanted to try it. Why not? :)

Game support isn't the best, but a lot of the popular ones play. SMB works,
all of the Mega Man games work, Contra, and many others. I'll be working on
compatibility fixes for future releases!

Notes: There are four quick-save slots. F1 to F4 saves, F5 to F8 loads!


Making it work
==============

If it crashes or has no audio, run the resreg.bat file *AS ADMINISTRATOR*
which will register a few files with Windows.


FAQ
===

Q: Does this support joysticks?
A: Sorry, not yet.

Q: Does this support controller 2?
A: Nope! Next version, I promise.

Q: It sounds like crap.
A: Working on it...

Q: Help, it's slow!
A: Yes, yes it is! Welcome to the world of VB6. You'll probably want at
   the very least, a high end Pentium 4. Even that will probably get
   frameskipped a little bit. Anything modern CPU should be more than enough.
   Anything but an Intel Atom, that is.

Q: Aren't there better languages to write this in?
A: Yep, and I've written one in C before. I just love VB6, I grew up on it.
   I wanted to give it some love!


Version history
===============

0.1.3 - Pretty much fixed MMC3 for most games. Added netplay support. Only seems reliable on LAN for now.

0.1.1 - Fixed bug where cancelling a load state dialog would crash the emulator.
      - Added support for 1x, 2x, 3x scaling selection.

0.1.0 - Initial release.
