Updates and content
--------------------------

Visia Compiler 4.8.7.zip

- is the original code of Visia Compiler.
Visia Compiler 4.8.7.zip


Visia Compiler 4.8.7.1.zip

- It contains a small and intelligent change suggested 
by Wilksey! (PSC programmer) which enables a real-time 
syntax highlighting.